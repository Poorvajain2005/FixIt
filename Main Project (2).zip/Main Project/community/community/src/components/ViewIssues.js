// ViewIssues.js
import { db } from './firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { useEffect, useState } from 'react';

function ViewIssues() {
  const [issues, setIssues] = useState([]);

  useEffect(() => {
    const q = query(collection(db, 'issues'), orderBy('timestamp', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const issuesList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setIssues(issuesList);
    });

    return () => unsubscribe(); // cleanup on unmount
  }, []);

  return (
    <div>
      <h2>Reported Issues</h2>
      <ul>
        {issues.map((issue) => (
          <li key={issue.id}>{issue.description} - {new Date(issue.timestamp?.toDate()).toLocaleString()}</li>
        ))}
      </ul>
    </div>
  );
}

export default ViewIssues;
