// PostIssue.js
import { db } from './firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { useState } from 'react';

function PostIssue() {
  const [description, setDescription] = useState('');

  const handleSubmit = async () => {
    try {
      await addDoc(collection(db, 'issues'), {
        description: description,
        timestamp: serverTimestamp()
      });
      alert('Issue submitted!');
      setDescription('');
    } catch (error) {
      console.error("Error posting issue:", error);
    }
  };

  return (
    <div>
      <h2>Report Issue</h2>
      <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}

export default PostIssue;
