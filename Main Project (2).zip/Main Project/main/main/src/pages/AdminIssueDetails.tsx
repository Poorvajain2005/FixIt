const AdminIssueDetails = () => {
  return <div>Admin Issue Details Page</div>;
};

export default AdminIssueDetails;