// src/pages/AdminDashboard.tsx
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAuth } from "firebase/auth";
import { collection, onSnapshot, updateDoc, doc } from "firebase/firestore";
import { db } from "../firebase"; // adjust if path differs

const AdminDashboard = () => {
  const [issues, setIssues] = useState<any[]>([]);
  const auth = getAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const user = auth.currentUser;
    if (!user || user.email !== "admin@fixit.com") {
      alert("Access Denied: Not an admin");
      navigate("/");
    }

    const unsub = onSnapshot(collection(db, "issues"), (snapshot) => {
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setIssues(data);
    });

    return () => unsub();
  }, []);

  const updateStatus = async (id: string, newStatus: string) => {
    const issueRef = doc(db, "issues", id);
    await updateDoc(issueRef, { status: newStatus });
  };

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      {issues.map((issue) => (
        <div key={issue.id} className="p-4 border rounded mb-4 shadow">
          <p><strong>Type:</strong> {issue.type}</p>
          <p><strong>Location:</strong> {issue.location}</p>
          <p><strong>Status:</strong> {issue.status}</p>
          <button
            className="bg-yellow-500 text-white px-3 py-1 mr-2 rounded"
            onClick={() => updateStatus(issue.id, "In Progress")}
          >
            In Progress
          </button>
          <button
            className="bg-green-600 text-white px-3 py-1 rounded"
            onClick={() => updateStatus(issue.id, "Resolved")}
          >
            Resolved
          </button>
        </div>
      ))}
    </div>
  );
};

export default AdminDashboard;
