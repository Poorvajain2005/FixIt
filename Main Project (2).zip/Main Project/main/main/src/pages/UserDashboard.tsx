import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { auth } from "@/firebase";
import { signOut } from "firebase/auth";
import { toast } from "sonner";

const UserDashboard = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast.success("Logged out successfully");
      navigate("/login");
    } catch (error) {
      toast.error("Logout failed");
      console.error("Logout error:", error);
    }
  };

  return (
    <div className="min-h-screen px-6 py-10 bg-gray-50">
      <div className="max-w-4xl mx-auto text-center">
        <h1 className="text-3xl font-bold text-fixit-blue">User Dashboard</h1>
        <p className="mt-2 text-muted-foreground">
          Welcome to your dashboard! You can view and report city issues here.
        </p>

        {/* Placeholder for future features */}
        <div className="mt-10">
          <div className="bg-white p-6 rounded-xl shadow-md">
            <p className="text-lg text-gray-600">🚧 Features coming soon!</p>
            <p className="text-sm text-gray-500 mt-2">
              You’ll be able to report issues, track your complaints, and more.
            </p>
          </div>
        </div>

        <Button className="mt-10" variant="outline" onClick={handleLogout}>
          Logout
        </Button>
      </div>
    </div>
  );
};

export default UserDashboard;
