const IssueReporter = () => {
  return <div>Issue Reporter Page</div>;
};

export default IssueReporter;