// src/firebase.ts
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyD0b6sggfKWd4CC7o9yPgo_ZBgCFAOw5dU",
  authDomain: "fixit-bf964.firebaseapp.com",
  projectId: "fixit-bf964",
  storageBucket: "fixit-bf964.firebasestorage.app",
  messagingSenderId: "977087047644",
  appId: "1:977087047644:web:3f10a350e3a64261371119",
  measurementId: "G-SK9HRV49LT"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);

// ✅ Export Firestore and Auth
export const db = getFirestore(app);
export const auth = getAuth(app);
