import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";

// Pages
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard"; // Community dashboard
import UserDashboard from "./pages/UserDashboard";   // Main dashboard

const AppRoutes = () => {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const isAdmin = user?.email?.toLowerCase() === "admin@fixit.com";

  if (loading) return <div className="text-center p-10">Loading...</div>;

  return (
    <Routes>
      {/* Redirect root route based on role */}
      <Route
        path="/"
        element={
          user ? (
            isAdmin ? <Navigate to="/community" replace /> : <Navigate to="/main" replace />
          ) : (
            <Navigate to="/login" replace />
          )
        }
      />

      {/* Admin Dashboard */}
      <Route
        path="/community"
        element={
          user && isAdmin ? <AdminDashboard /> : <Navigate to="/login" replace />
        }
      />

      {/* User Dashboard */}
      <Route
        path="/main"
        element={
          user && !isAdmin ? <UserDashboard /> : <Navigate to="/login" replace />
        }
      />

      {/* Login Page */}
      <Route
        path="/login"
        element={
          user ? (
            <Navigate to={isAdmin ? "/community" : "/main"} replace />
          ) : (
            <Login />
          )
        }
      />

      {/* 404 fallback */}
      <Route path="*" element={<div className="p-10 text-center">404 | Page Not Found</div>} />
    </Routes>
  );
};

export default AppRoutes;
